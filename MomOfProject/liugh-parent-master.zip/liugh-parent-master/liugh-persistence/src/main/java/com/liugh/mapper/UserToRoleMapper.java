package com.liugh.mapper;

import com.liugh.entity.UserToRole;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liugh123
 * @since 2018-05-03
 */
public interface UserToRoleMapper extends BaseMapper<UserToRole> {

}

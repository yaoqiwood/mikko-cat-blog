package com.liugh.mapper;

import com.liugh.entity.Role;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liugh123
 * @since 2018-05-03
 */
public interface RoleMapper extends BaseMapper<Role> {

}

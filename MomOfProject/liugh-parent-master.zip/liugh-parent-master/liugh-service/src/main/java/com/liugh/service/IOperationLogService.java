package com.liugh.service;

import com.liugh.entity.OperationLog;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 操作日志 服务类
 * </p>
 *
 * @author liugh123
 * @since 2018-05-08
 */
public interface IOperationLogService extends IService<OperationLog> {

}
